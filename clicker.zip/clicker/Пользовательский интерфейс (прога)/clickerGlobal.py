from tkinter import *

root = Tk()
root.title('Счетчик кликов')
root.geometry('360x400')
root.resizable(width=False, height=False)
root.iconbitmap('C:/Users/achebotarev/Desktop/clicker/cursor_click.ico')

count = 0


def  clicked():
    global count
    count += 1
    Click.configure(text=count)

def click():
    root = Tk()
    root.title('Магазин Кликера (UPDATES)')
    root.geometry('600x400')
    root.resizable(width=False, height=False)
    root.iconbitmap('C:/Users/achebotarev/Desktop/clicker/marketClicker.ico')

    balance = 'Баланс: '+str(count)

    Click = Label(root, text='МАГАЗИН', font='Arial 35')
    Click.pack()

    Click = Label(root, text=balance, font='Arial 35')
    Click.pack()
    
def  reset():
    global count
    count = 0
    Click.configure(text=count)

    
       
Click = Label(root, text='0', font='Arial 35')
Click.pack()

btn = Button(root, text='Клик!', padx='20', pady='20', command=clicked)
btn.pack()

btn = Button(root, text='Магазин', padx='20', pady='20', command=click)
btn.pack()

btn = Button(root, text='Очистить', padx='20', pady='20', command=reset)
btn.pack()

root.mainloop()
