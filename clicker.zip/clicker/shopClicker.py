from tkinter import *

root = Tk()
root.title('Магазин Кликера (UPDATES)')
root.geometry('600x400')
root.resizable(width=False, height=False)
root.iconbitmap('C:/Users/achebotarev/Desktop/clicker/marketClicker.ico')

Click = Label(root, text='МАГАЗИН', font='Arial 35')
Click.pack()

root.mainloop()
